var struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a =
[
    [ "issuer", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a8ace66d00e38a7b8940c3c6cec996b34", null ],
    [ "next", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a7d6270d31f3ddf2279e567fea389db45", null ],
    [ "signature", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a30ec85ba5d5ba40af358c798dc39c20a", null ],
    [ "subject", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#aa5d87430c2d4d5cfdadaca521a26477e", null ],
    [ "validFrom", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a5c7b1424ad82202f8667ed5872439873", null ],
    [ "validTo", "struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a57bbcce73f5446f1c591c97b5f58a0b9", null ]
];