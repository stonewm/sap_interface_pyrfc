var struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s =
[
    [ "client", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a4e2ef95e0602e151742a8e198be465c3", null ],
    [ "hostname", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a2269d28183cf3e2b4bf62b75a84aeaba", null ],
    [ "kernelTrace", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a0e0e1d5663b4ec47612352cf8120ad02", null ],
    [ "lock", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a34f64d382442b2229168e928b6463bca", null ],
    [ "noCommitCheck", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#acb00933ba534db8226bc42a25626bc51", null ],
    [ "program", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ab9ec4b21c8dbf3e38527fc2c0477392f", null ],
    [ "satTrace", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a2828b0eec0a2cd6196d4be79a32a9e41", null ],
    [ "sendingDate", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a97305a2c852ab9324b769a9eeb5295f3", null ],
    [ "sendingTime", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ad3b159f33f609e9bf5ce95252e4b5f98", null ],
    [ "tCode", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ab62a37fe8e3b9b132bbf3aedc0bfd0f3", null ],
    [ "unitHistory", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ae1c21b150c419b2f920472f7b5526064", null ],
    [ "user", "struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a830c2fbe313993ecfbb8191a905c2181", null ]
];