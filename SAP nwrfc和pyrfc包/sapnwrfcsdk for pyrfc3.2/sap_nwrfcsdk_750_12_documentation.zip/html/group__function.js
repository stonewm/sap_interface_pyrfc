var group__function =
[
    [ "RfcAddException", "group__function.html#ga29dcdaec46813f94ff524a7e2d4e60ba", null ],
    [ "RfcAddParameter", "group__function.html#gab58991b3e0667c2a3c9e6cd87bbc85b5", null ],
    [ "RfcCreateFunctionDesc", "group__function.html#ga1e95724a87133e5cdeb0c33671de079c", null ],
    [ "RfcDestroyFunctionDesc", "group__function.html#ga051bdc28523ebb1183b2a013aad4cae0", null ],
    [ "RfcEnableAbapClassException", "group__function.html#gab2d7758f3d8d1906fdfcc3af2570a0e6", null ],
    [ "RfcEnableBASXML", "group__function.html#gaaeb3cc65a48e1c6b6f848f3cf73991ca", null ],
    [ "RfcGetExceptionCount", "group__function.html#gaad539cebd9c6b5f7f26d1c5ed32aa438", null ],
    [ "RfcGetExceptionDescByIndex", "group__function.html#ga60620eb198d590f36f203384e38f5477", null ],
    [ "RfcGetExceptionDescByName", "group__function.html#gaccdfcf4dd62b717ac29a387b5f3e243d", null ],
    [ "RfcGetFunctionName", "group__function.html#ga940b88b09d66bddebdbb49f05de30cf9", null ],
    [ "RfcGetParameterCount", "group__function.html#ga9e4fc62d829114e0c4d8ddb1be0020b8", null ],
    [ "RfcGetParameterDescByIndex", "group__function.html#ga58811488e9ec920e3fd337f9ec561881", null ],
    [ "RfcGetParameterDescByName", "group__function.html#ga143095f5d517550715080bd79f9232c0", null ],
    [ "RfcIsAbapClassExceptionEnabled", "group__function.html#ga4922962f78cfd4be8e78ebf3c29832ac", null ],
    [ "RfcIsBASXMLSupported", "group__function.html#ga2ca6ab92f373d3e9935ba8f92524298b", null ]
];