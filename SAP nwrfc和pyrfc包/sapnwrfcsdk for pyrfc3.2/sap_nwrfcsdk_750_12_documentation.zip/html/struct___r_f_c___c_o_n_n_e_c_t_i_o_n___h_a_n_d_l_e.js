var struct___r_f_c___c_o_n_n_e_c_t_i_o_n___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___h_a_n_d_l_e.html#a5b7f0bf4b9ae820582c8ea4acc3af9f2", null ]
];