var struct___r_f_c___f_u_n_c_t_i_o_n___d_e_s_c___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___f_u_n_c_t_i_o_n___d_e_s_c___h_a_n_d_l_e.html#ad68f8fd68c71b274feb5ce34461f799c", null ]
];