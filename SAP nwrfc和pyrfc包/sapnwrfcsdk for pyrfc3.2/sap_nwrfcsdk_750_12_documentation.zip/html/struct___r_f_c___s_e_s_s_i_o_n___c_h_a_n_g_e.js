var struct___r_f_c___s_e_s_s_i_o_n___c_h_a_n_g_e =
[
    [ "event", "struct___r_f_c___s_e_s_s_i_o_n___c_h_a_n_g_e.html#ae79ae4074dd369a3c9ce4aa601156783", null ],
    [ "sessionID", "struct___r_f_c___s_e_s_s_i_o_n___c_h_a_n_g_e.html#af2be0df0defe6aa5c00dbb607ecb1035", null ]
];