var struct___r_f_c___c_l_a_s_s___d_e_s_c___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___c_l_a_s_s___d_e_s_c___h_a_n_d_l_e.html#afa740a19fb9a84b7f4139f6140167675", null ]
];