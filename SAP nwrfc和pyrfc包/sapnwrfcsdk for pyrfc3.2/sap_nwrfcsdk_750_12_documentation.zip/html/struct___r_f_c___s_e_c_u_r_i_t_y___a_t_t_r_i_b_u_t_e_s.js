var struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s =
[
    [ "client", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a7363655e5a8aaf96d228e24f1444b12a", null ],
    [ "functionName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a5e1f0e4935068ff402dab41501a553e7", null ],
    [ "progName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a73c1cb8b9aeaa112bcb39bbf499814c3", null ],
    [ "sncAclKey", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a26a343851c103a22a8fe9f9f68975503", null ],
    [ "sncAclKeyLength", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#aa5477e8fde6f51992561ebb849408f4a", null ],
    [ "sncName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a4a46ea247323a1c5bd6510361c6e933b", null ],
    [ "ssoTicket", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#af384c9d6f380719f53019a96e5a71e6a", null ],
    [ "sysId", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#ab779826559856ce36f7680cb3a17e6bd", null ],
    [ "user", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a612941028fb8bf5cc4931a75969757f3", null ]
];