var searchData=
[
  ['language',['language',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a6ff947dc392f2787663eb8afd0e145a2',1,'_RFC_ATTRIBUTES']]],
  ['lastactivity',['lastActivity',['../struct___r_f_c___s_e_r_v_e_r___m_o_n_i_t_o_r___d_a_t_a.html#a09f113721cceeab4e22b0c426910eb04',1,'_RFC_SERVER_MONITOR_DATA']]],
  ['lock',['lock',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a34f64d382442b2229168e928b6463bca',1,'_RFC_UNIT_ATTRIBUTES']]]
];
