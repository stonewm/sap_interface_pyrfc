var searchData=
[
  ['errormessage',['errorMessage',['../struct___r_f_c___m_e_t_a_d_a_t_a___q_u_e_r_y___r_e_s_u_l_t___e_n_t_r_y.html#a70ea8945e1170d546d1d2e309679dba3',1,'_RFC_METADATA_QUERY_RESULT_ENTRY']]],
  ['event',['event',['../struct___r_f_c___s_e_s_s_i_o_n___c_h_a_n_g_e.html#ae79ae4074dd369a3c9ce4aa601156783',1,'_RFC_SESSION_CHANGE']]],
  ['extendeddescription',['extendedDescription',['../struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a75c7afde51a50480913b9bdfb8e6493a',1,'_RFC_FIELD_DESC::extendedDescription()'],['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#af0f2a99370a4c387ee0d9725d67e646a',1,'_RFC_PARAMETER_DESC::extendedDescription()'],['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a840af76b41f2dda7efd7adaf409a1304',1,'_RFC_CLASS_ATTRIBUTE_DESC::extendedDescription()']]],
  ['external_5fapplication_5ffailure',['EXTERNAL_APPLICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a9caa0231be888ebf92a708f6df13f8a3',1,'sapnwrfc.h']]],
  ['external_5fauthentication_5ffailure',['EXTERNAL_AUTHENTICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6ac4ae691ef701ca72ea587f18bd4505b8',1,'sapnwrfc.h']]],
  ['external_5fauthorization_5ffailure',['EXTERNAL_AUTHORIZATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a202cc24d3b7760c4b6b874297e0aaa75',1,'sapnwrfc.h']]],
  ['external_5fruntime_5ffailure',['EXTERNAL_RUNTIME_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6af4f6dff366d5989456eb5aeafcfefee2',1,'sapnwrfc.h']]]
];
