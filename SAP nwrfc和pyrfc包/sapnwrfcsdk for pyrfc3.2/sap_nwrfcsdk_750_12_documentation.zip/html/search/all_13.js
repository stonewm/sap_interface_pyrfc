var searchData=
[
  ['tcode',['tCode',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ab62a37fe8e3b9b132bbf3aedc0bfd0f3',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['tid',['tid',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abc60d0479b6ae2895d06ea6bdb4a7968',1,'_RFC_SERVER_CONTEXT']]],
  ['trace',['trace',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aae258e8152c702f531c55f6ca78feabd',1,'_RFC_ATTRIBUTES']]],
  ['transaction_20_28trfc_20_26_20qrfc_29_20api',['Transaction (tRFC &amp; qRFC) API',['../group__transaction.html',1,'']]],
  ['true',['TRUE',['../doxyfile__nrfc__public_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'doxyfile_nrfc_public.h']]],
  ['type',['type',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a8e2610634ba3e8dd0f1ba8a04968f618',1,'_RFC_ATTRIBUTES::type()'],['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a74d22c358223c858de6e4acf0bef1a7b',1,'_RFC_SERVER_CONTEXT::type()'],['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a31e80e7bcf1f36cfa1c58486ba05aba6',1,'_RFC_SERVER_ATTRIBUTES::type()'],['../struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a7dc53826d63143bf1f809a59383a9acb',1,'_RFC_FIELD_DESC::type()'],['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a8175e09cfb3b96993af74b5e40e46031',1,'_RFC_PARAMETER_DESC::type()'],['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a2c5481818031f7f0dbbc45feccdda43a',1,'_RFC_CLASS_ATTRIBUTE_DESC::type()']]],
  ['typedeschandle',['typeDescHandle',['../struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a859f44444ad64d816a866646984dc6a4',1,'_RFC_FIELD_DESC::typeDescHandle()'],['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#adb6617f3817e79137592ebd3a56008cb',1,'_RFC_PARAMETER_DESC::typeDescHandle()'],['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#ac26bfc62adb11549889aef21dbcadff6',1,'_RFC_CLASS_ATTRIBUTE_DESC::typeDescHandle()']]]
];
