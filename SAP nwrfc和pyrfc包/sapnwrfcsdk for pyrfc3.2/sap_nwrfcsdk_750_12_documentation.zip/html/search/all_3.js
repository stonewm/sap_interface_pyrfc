var searchData=
[
  ['client',['client',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ab49af0266a6c233a16b63a555ad57cc9',1,'_RFC_ATTRIBUTES::client()'],['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a7363655e5a8aaf96d228e24f1444b12a',1,'_RFC_SECURITY_ATTRIBUTES::client()'],['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a4e2ef95e0602e151742a8e198be465c3',1,'_RFC_UNIT_ATTRIBUTES::client()']]],
  ['clientinfo',['clientInfo',['../struct___r_f_c___s_e_r_v_e_r___m_o_n_i_t_o_r___d_a_t_a.html#ae6cf1a195f888e623fb73239b92c1fd5',1,'_RFC_SERVER_MONITOR_DATA']]],
  ['code',['code',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a136ec745ede4687b7b1520b8badeddc6',1,'_RFC_ERROR_INFO']]],
  ['codepage',['codepage',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aa1b6f0b745762f13322d5d2c8e9f71bd',1,'_RFC_ATTRIBUTES']]],
  ['communication_5ffailure',['COMMUNICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a41d6abb3e5d6782202ec19b2c9572c97',1,'sapnwrfc.h']]],
  ['connection_20related_20api',['Connection related API',['../group__connection.html',1,'']]],
  ['cpicconvid',['cpicConvId',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aa0d9fba558d08eb03d627a08d4612f8c',1,'_RFC_ATTRIBUTES']]],
  ['cryptolib_5ffailure',['CRYPTOLIB_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a44159a0875c75aed1b7ba05a9b600c2e',1,'sapnwrfc.h']]],
  ['currentbusycount',['currentBusyCount',['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a80ae1ac8f5e2bbeb33094bf545401ccf',1,'_RFC_SERVER_ATTRIBUTES']]]
];
