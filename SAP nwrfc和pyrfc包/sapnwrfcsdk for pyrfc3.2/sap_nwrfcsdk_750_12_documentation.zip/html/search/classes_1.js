var searchData=
[
  ['rfc_5fabap_5fobject_5fhandle',['RFC_ABAP_OBJECT_HANDLE',['../struct_r_f_c___a_b_a_p___o_b_j_e_c_t___h_a_n_d_l_e.html',1,'']]],
  ['rfc_5fdata_5fcontainer',['RFC_DATA_CONTAINER',['../struct_r_f_c___d_a_t_a___c_o_n_t_a_i_n_e_r.html',1,'']]],
  ['rfc_5ffunction_5fhandle',['RFC_FUNCTION_HANDLE',['../struct_r_f_c___f_u_n_c_t_i_o_n___h_a_n_d_l_e.html',1,'']]],
  ['rfc_5fstructure_5fhandle',['RFC_STRUCTURE_HANDLE',['../struct_r_f_c___s_t_r_u_c_t_u_r_e___h_a_n_d_l_e.html',1,'']]],
  ['rfc_5ftable_5fhandle',['RFC_TABLE_HANDLE',['../struct_r_f_c___t_a_b_l_e___h_a_n_d_l_e.html',1,'']]]
];
