var searchData=
[
  ['true',['TRUE',['../doxyfile__nrfc__public_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'doxyfile_nrfc_public.h']]]
];
