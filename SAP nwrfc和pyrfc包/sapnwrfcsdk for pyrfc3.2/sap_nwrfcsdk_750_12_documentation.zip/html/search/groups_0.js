var searchData=
[
  ['api_20for_20automated_20servers',['API for Automated Servers',['../group__autoserver.html',1,'']]]
];
