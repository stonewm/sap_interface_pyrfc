var searchData=
[
  ['background_20communication_20_28bgrfc_29_20api',['Background Communication (bgRFC) API',['../group__bgrfc.html',1,'']]]
];
