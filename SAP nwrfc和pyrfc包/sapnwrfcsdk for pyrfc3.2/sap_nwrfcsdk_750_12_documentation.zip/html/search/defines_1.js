var searchData=
[
  ['rfc_5ftid_5fln',['RFC_TID_LN',['../sapnwrfc_8h.html#a663890917240c9dc78163c00e22b3c03',1,'sapnwrfc.h']]],
  ['rfc_5funitid_5fln',['RFC_UNITID_LN',['../sapnwrfc_8h.html#ac035107a50eee75495ed5ff7407437f0',1,'sapnwrfc.h']]]
];
