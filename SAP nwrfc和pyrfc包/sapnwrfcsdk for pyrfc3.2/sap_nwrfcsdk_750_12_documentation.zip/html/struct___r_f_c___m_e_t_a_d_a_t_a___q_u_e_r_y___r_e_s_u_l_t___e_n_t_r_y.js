var struct___r_f_c___m_e_t_a_d_a_t_a___q_u_e_r_y___r_e_s_u_l_t___e_n_t_r_y =
[
    [ "errorMessage", "struct___r_f_c___m_e_t_a_d_a_t_a___q_u_e_r_y___r_e_s_u_l_t___e_n_t_r_y.html#a70ea8945e1170d546d1d2e309679dba3", null ],
    [ "name", "struct___r_f_c___m_e_t_a_d_a_t_a___q_u_e_r_y___r_e_s_u_l_t___e_n_t_r_y.html#ac76e990da410b9f4c657bc7ec32980c4", null ]
];